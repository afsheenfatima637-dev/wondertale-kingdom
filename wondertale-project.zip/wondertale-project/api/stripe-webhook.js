// api/stripe-webhook.js
//
// Stripe calls this endpoint directly (not the browser) to tell you what actually
// happened — a successful payment, a cancellation, a failed renewal, etc.
// Never trust the success_url redirect alone for "did they actually pay" — a user
// can land on that URL without paying (closed tab, back button, etc). This webhook
// is the source of truth.
//
// NOTE: this currently just logs events. Wiring it to your database (marking a
// user's account as "premium") is the next step once you have a database at all.

import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

export const config = {
  api: { bodyParser: false }, // Stripe requires the raw request body to verify the signature
};

function buffer(readable) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    readable.on("data", (chunk) => chunks.push(chunk));
    readable.on("end", () => resolve(Buffer.concat(chunks)));
    readable.on("error", reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).end("Method not allowed");
  }

  const sig = req.headers["stripe-signature"];
  let event;

  try {
    const rawBody = await buffer(req);
    event = stripe.webhooks.constructEvent(rawBody, sig, endpointSecret);
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case "checkout.session.completed":
      // TODO: mark this customer as premium in your database
      console.log("Checkout completed for session:", event.data.object.id);
      break;
    case "customer.subscription.deleted":
      // TODO: mark this customer as no longer premium
      console.log("Subscription canceled:", event.data.object.id);
      break;
    case "invoice.payment_failed":
      // TODO: consider notifying the user their card was declined
      console.log("Payment failed for invoice:", event.data.object.id);
      break;
    default:
      console.log(`Unhandled event type: ${event.type}`);
  }

  res.status(200).json({ received: true });
}
